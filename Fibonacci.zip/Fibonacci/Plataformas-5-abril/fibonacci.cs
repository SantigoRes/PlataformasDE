﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plataformas_5_abril
{
    class fibonacci
    {
        int cantidad;
        int []vector1;
        public fibonacci(int cantidad)
        {
            this.vector1 = new int[cantidad + 1];
            this.cantidad = cantidad;
        }

        int a = 0, b = 1, auxiliar = 0;

         public void metodoFibonacci() {
            for (int i =0;i<cantidad;i++) {
                auxiliar = a;
                a = b;
                b = auxiliar + a;
                vector1[i] = a;
            }
        }

         public void escribir (){
            for (int i= vector1.Length -2; i >= 0; i--) {
                Console.WriteLine(vector1[i]);
                
            }
            Console.Read();
        }
    
        
        
    }
}
