﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plataformas_5_abril
{
    class Program
    {
        static void Main(string[] args)
        {
           // pureba codigo fibonacci
             Console.WriteLine("Cuantos numeros fibonacci quiere");
            int cantidad= int.Parse(Console.ReadLine());

            fibonacci prueba = new fibonacci(cantidad);
            prueba.metodoFibonacci();
            prueba.escribir();
    
            Console.ReadLine();




        }
    }
}
