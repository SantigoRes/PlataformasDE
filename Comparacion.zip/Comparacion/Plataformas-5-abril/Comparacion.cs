﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plataformas_5_abril
{
    class Comparacion
    {
        string cadena;
        public Comparacion(string cadena)
        {
            this.cadena = cadena;
        }
        char delimitadro = ',';
        int comp12;
        int comp13;
        int comp23;
        string[] valores;

         public void Comparar() {

            valores = cadena.Split(delimitadro);
            comp12 = valores[0].CompareTo(valores[1]);
            comp13 = valores[0].CompareTo(valores[2]);
            comp23 = valores[1].CompareTo(valores[2]);
        }

        public string Retornar() {
            string retorno="falso";
            if (comp12<0 && comp23<0) {
                retorno = "Verdadero";
            }
            if (comp12>0 && comp13>0 && comp23<0 ) {
                retorno = "Verdadero";
            }
            if (comp12 <0 && comp13 == 0 )
            {
                retorno = "verdadero";
            }
            

            return retorno;

        }

        

    }
}
