﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plataformas_5_abril
{
    class Program
    {
        static void Main(string[] args)
        {
           

            Console.WriteLine("ingrese las 3 palabras separadas por ,");
            string cadena = Console.ReadLine();
            Comparacion pruebita2 = new Comparacion(cadena);
            pruebita2.comparar();
            cadena = pruebita2.retornar();
            Console.WriteLine(cadena);
            Console.ReadLine();




        }
    }
}
